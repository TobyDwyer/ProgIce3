﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERQueueSystem
{
    internal class PriorityQueue<T>
    {
        private List<Tuple<T, int>> _elements = new List<Tuple<T, int>>();

        public int Count => _elements.Count;

        // Adds an item to the queue with a given priority
        public void Enqueue(T item, int priority)
        {
            _elements.Add(Tuple.Create(item, priority));
        }

        // Removes and returns the item with the highest priority
        public T Dequeue()
        {
            var highestPriority = _elements[0];
            foreach (var element in _elements)
            {
                if (element.Item2 > highestPriority.Item2)
                {
                    highestPriority = element;
                }
            }

            _elements.Remove(highestPriority);
            return highestPriority.Item1;
        }
    }
}
