﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERQueueSystem
{
    internal class Patient
    {
        public string Name { get; set; }
        public int SeverityLevel { get; set; }

        public Patient(string name, int severityLevel)
        {
            Name = name;
            SeverityLevel = severityLevel;
        }

        public override string ToString()
        {
            return $"Patient: {Name}, Severity: {SeverityLevel}";
        }
    }
}
