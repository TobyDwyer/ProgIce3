﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ERQueueSystem
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var erQueue = new PriorityQueue<Patient>();

            // Input the number of patients
            Console.Write("Enter the number of patients to add: ");
            int numberOfPatients = int.Parse(Console.ReadLine());

            // Add patients dynamically
            for (int i = 0; i < numberOfPatients; i++)
            {
                Console.WriteLine($"Enter details for patient {i + 1}:");

                Console.Write("Patient Name: ");
                string name = Console.ReadLine();

                Console.Write("Severity Level (higher number = more severe): ");
                int severity = int.Parse(Console.ReadLine());

                erQueue.Enqueue(new Patient(name, severity), severity);
            }

            // Treating patients based on severity
            Console.WriteLine("\nTreating patients based on severity...");
            while (erQueue.Count > 0)
            {
                var patient = erQueue.Dequeue();
                Console.WriteLine(patient);
            }

            // Pause to display the output
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}
